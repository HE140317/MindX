
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Dell
 */
public class Main {

    static Scanner sc = new Scanner(System.in);

    static int checkInt(String msg, int Min, int Max) {
        int input;
        do {
            System.out.println(msg);
            try {
                input = Integer.parseInt(sc.nextLine());
                if (input >= Min && input <= Max && (input % 2 == 0)) {
                    break;
                } else {
                    System.out.println("Invalid!!");
                }
            } catch (Exception e) {
                System.out.println("Invalid input, try again!");
            }
        } while (true);
        return input;
    }
        static int inputInt(String msg, int Min, int Max) {
        int input;
        do {
            System.out.println(msg);
            try {
                input = Integer.parseInt(sc.nextLine());
                if (input >= Min && input <= Max ) {
                    break;
                } else {
                    System.out.println("Invalid!!");
                }
            } catch (Exception e) {
                System.out.println("Invalid input, try again!");
            }
        } while (true);
        return input;
    }
    
    
    static int findOppositeNumber(int n, int inputNumber) {
        int oppNum;
        if ((inputNumber+n/2) < n) {
            return oppNum = inputNumber + n/2 ;
        }else
            return oppNum = inputNumber - n/2;    
    }

    public static void main(String[] args) {
        int n = checkInt("Enter numbers of number in circle", 4, 20);
        int inputNumber = inputInt("Enter number", 0, n-1);
        System.out.println(findOppositeNumber(n, inputNumber));
    }
}
