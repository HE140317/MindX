
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Dell
 */
public class Main {
    
    static Scanner sc = new Scanner(System.in);
    
    public static void main(String[] args) {
        String a = sc.nextLine().trim();
        String b = sc.nextLine().trim();
        int sizeA = a.length();
        int sizeB = b.length();
        char[] c = new char[sizeA+sizeB];
        int min = Integer.min(sizeA, sizeB);
        int j =0;
        int i;
        for (i = 0; i < min; i++, j+=2) {
            c[j] = a.charAt(i);
            c[j+1] = b.charAt(i);
        }
        while (i < sizeA) {            
            c[j++] = a.charAt(i++);
        }
        while (i < sizeB) {            
            c[j++] = b.charAt(i++);
        }
        System.out.println(c);
    }
}
